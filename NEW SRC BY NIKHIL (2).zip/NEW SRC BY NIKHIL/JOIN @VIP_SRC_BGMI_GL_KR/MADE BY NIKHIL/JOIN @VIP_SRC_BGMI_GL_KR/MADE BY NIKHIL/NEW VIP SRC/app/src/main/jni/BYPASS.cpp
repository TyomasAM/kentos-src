
#include "patch/Logger.h"
#include "patch/obfuscate.h"
#include "patch/Utils.h"
#include "patch/MemoryPatch.h"
#include "patch/SubstrateHook.h"
#include "patch/Macros.h"
#include <list>
#include <vector>
#include <string>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <chrono> 
#include <fcntl.h>
#include <sys/stat.h>
#include <cstddef>
#include <semaphore.h>
#include <stdint.h>
#include <sstream>
#include <stdarg.h>
#include <stdio.h>
#include <curl/curl.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>c
using namespace std;
#define __int8 char
#define __int16 short
#define __int32 int
#define __int64 long long
#define _BYTE  uint8_t
#define _WORD  uint16_t
#define _DWORD uint32_t
#define _QWORD uint64_t
#define _QWORD __int64
#define targetLibName ("libRoosterNN.so")
#define targetLibName ("libTDataMaster.so")
#define targetLibName ("libTDataMaster.so")
#define targetLibName ("libAntsVoice.so")
#define gcc_va_list
#define BYTE4
#define HIBYTE
#define BYTE6
#define BYTE1
#define BYTE3
#define ARM64_SYSREG
#define _WriteStatusReg
bool EnableLog = true;//change to false in production
bool UserLogined = false;
bool UserFired = false;
DWORD OriginalStackCheck = 0;
#define pkgName "com.pubg.imobile"
#pragma pack(1)
struct patch_t
{
    _BYTE nPatchType;
    DWORD dwAddress;
};
#pragma pack()

#include <stdio.h>
#include <dlfcn.h>

DWORD libTDataMasterBase = 0;
DWORD libTDataMasterSize = 0;
DWORD libanogsBase = 0;
DWORD libUE4Base = 0;
DWORD libanortBase = 0;
DWORD libEGLBase = 0;
DWORD libanogsAlloc = 0;
DWORD libTDataMasterAlloc = 0;
DWORD libUE4Alloc = 0;
DWORD libEGLAlloc = 0;
unsigned int libanogsSize  = 0x476FF9;
unsigned int libUE4Size  = 0xA9CFBA0;
char *Offset;
DWORD NewBase = 0;

typedef unsigned char BYTE;   // 8-bit unsigned entity.
typedef BYTE* PBYTE;  // Pointer to BYTE.
#define Owner = "UNITY ANTIBAN"
#define PackageName "com.pubg.imobile"


#define targetLibName OBFUSCATE("libanogs.so")
#define targetLibName OBFUSCATE("libhdmpve.so")
#define targetLibName OBFUSCATE("libanort.so")
#define targetLibName OBFUSCATE("libTBlueData.so")
#define targetLibName OBFUSCATE("libCrashKit.so")

auto ret = reinterpret_cast<uintptr_t>(__builtin_return_address(0));



using namespace std;
#define __int8 char
#define __int16 short
#define __int32 int
#define __int64 long long
#define _BYTE  uint8_t
#define _WORD  uint16_t
#define _DWORD uint32_t
#define _QWORD uint64_t

#define targetLibName OBFUSCATE("libUE4.so")
#define targetLibName OBFUSCATE("libanogs.so")

#define _BYTE  uint8_t
#define _WORD  uint16_t
#define _DWORD uint32_t
#define _QWORD uint64_t
#define _OWORD uint64_t

#define _BOOL8 uint64_t

class UBulletHitInfoUploadComponent
{
public:
    bool bEnableTssSdkAntiData;
    bool bEnableTssSdkAntiDataFilter;
    bool bEnableTssSdkAntiDataFilterNew;
    bool bDisableDsTick;
    bool bDisableDsAntiDataReport;
    bool bEnableAddSPCShootData;
    bool NeedSendSimpleCharacterHitData;
};



DWORD TBlueBase = 0;
DWORD AntBase = 0;
DWORD BufferBase = 0;
DWORD HdmpveBase = 0;
DWORD roosterBase = 0;
DWORD roosterSize = 0;
DWORD roosterAlloc = 0;

DWORD EGLBase = 0;
DWORD EGLSize = 0;
DWORD EGLAlloc = 0;

DWORD libcBase = 0;
DWORD libcSize = 0;
DWORD libcAlloc = 0;




bool WriteAddress(void *addr, void *buffer, size_t length) {
    unsigned long page_size = sysconf(_SC_PAGESIZE);
    unsigned long size = page_size * sizeof(uintptr_t);
    return mprotect((void *) ((uintptr_t) addr - ((uintptr_t) addr % page_size) - page_size), (size_t) size, PROT_EXEC | PROT_READ | PROT_WRITE) == 0 && memcpy(addr, buffer, length) != 0;
}
uintptr_t S2O(const char *c) {
    int base = 16;
    // See if this function catches all possibilities.
    // If it doesn't, the function would have to be amended
    // whenever you add a combination of architecture and
    // compiler that is not yet addressed.
    static_assert(sizeof(uintptr_t) == sizeof(unsigned long)
                  || sizeof(uintptr_t) == sizeof(unsigned long long),
                  "Please add string to handle conversion for this architecture.");

    // Now choose the correct function ...
    if (sizeof(uintptr_t) == sizeof(unsigned long)) {
        return strtoul(c, nullptr, base);
    }

    // All other options exhausted, sizeof(uintptr_t) == sizeof(unsigned long long))
    return strtoull(c, nullptr, base);
}

size_t getLibrarySize(const char *libraryName)
{
    FILE *mapsFile = fopen("/proc/self/maps", "r");
    if (mapsFile == nullptr)
    {
        return 0;
    }

    char line[256];
    size_t size = 0;
    uintptr_t startAddr = 0, endAddr = 0;
    while (fgets(line, sizeof(line), mapsFile))
    {
        if (strstr(line, libraryName))
        {
            sscanf(line, "%lx-%lx", &startAddr, &endAddr);
            size = endAddr - startAddr;
            break;
        }
    }

    fclose(mapsFile);
    return size;
}

int RET()
{
return 0LL;//RET
}






__int64 __fastcall  Nikhil ( __int64 a1, __int64 a2, __int64 a3)
{
auto ret = reinterpret_cast<uintptr_t>(__builtin_return_address(0));
LOGI("ret : %0",ret);
 if (ret == 0xE0970){
sleep(10000);
}
}


void *Vip_thread(void *) {
  while (!isLibraryLoaded("libUE4.so")) { sleep(1); }
    while (!isLibraryLoaded("libanogs.so")) { sleep(1); }
    LOGI(" BYPASS DONE ");
    system(OBFUSCATE("rm -rf /data/data/com.pubg.imobile/files/ano_tmp; touch /data/data/com.pubg.imobilex/files/ano_tmp"));
    libanogsBase = findLibrary(OBFUSCATE("libanogs.so"));
    libUE4Base = findLibrary(OBFUSCATE("libUE4.so"));
    EGLBase = findLibrary(OBFUSCATE("libEGL.so"));
    TBlueBase = findLibrary(OBFUSCATE("libTBlueData.so"));
    libanortBase = findLibrary(OBFUSCATE("libanort.so"));
    AntBase = findLibrary(OBFUSCATE("libAntsVoice.so"));
    HdmpveBase = findLibrary(OBFUSCATE("libhdmpve.so"));
    libcBase = findLibrary(OBFUSCATE("libc.so"));
    uintptr_t adreno = findLibrary(OBFUSCATE("libGLESv2_adreno.so"));
    BufferBase = findLibrary(OBFUSCATE("libstagefright_bufferpool@2.0.1.so"));
    libanogsSize = getLibrarySize(OBFUSCATE("libanogs.so"));
    libUE4Size =   getLibrarySize(OBFUSCATE("libUE4.so"));
    libanogsAlloc = (DWORD)malloc(libanogsSize);
    libUE4Alloc   = (DWORD)malloc(libUE4Size);
    memcpy((void *)libanogsAlloc, (void *)libanogsBase, libanogsSize);
    memcpy((void *)libUE4Alloc, (void *)libUE4Base, libUE4Size);
    void *handle = dlopen(OBFUSCATE("libc.so"), 4);
    void *pthread_create_addr   = dlsym(handle, OBFUSCATE("pthread_create"));
    void *inet_pton_addr   = dlsym(handle, OBFUSCATE("inet_pton"));
    dlclose(handle);

HOOK_LIB_NO_ORIG("libanogs.so","0xE0970", Nikhil);

return NULL;   
}

__attribute__((constructor)) void mainload() {
pthread_t ptid;
pthread_create(&ptid, NULL, Vip_thread, NULL);
pthread_t t;
}

