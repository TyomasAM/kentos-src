#pragma once

// PlayerUnKnowns BattleGrounds Global-64bit (3.2.0) SDK BY @MirWani 

#include "../SDK.hpp"

namespace SDK
{
//---------------------by MirWani---------------------------
//Parameters
//---------------------by MirWani---------------------------

// Function LuaHotReload.LuaHotReloadHelper.OnLuaFileHotUpdate
struct ULuaHotReloadHelper_OnLuaFileHotUpdate_Params
{
	struct FString                                     NotifyMessage;                                            // (Parm, ZeroConstructor)
};

}

