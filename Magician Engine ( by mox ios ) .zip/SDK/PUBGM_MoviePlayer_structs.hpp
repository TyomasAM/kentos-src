#pragma once

// PlayerUnKnowns BattleGrounds Global-64bit (3.2.0) SDK BY @MirWani 

namespace SDK
{
//---------------------by MirWani---------------------------
//Enums
//---------------------by MirWani---------------------------

// Enum MoviePlayer.EMoviePlaybackType
enum class EMoviePlaybackType : uint8_t
{
	MT_Normal                      = 0,
	MT_Looped                      = 1,
	MT_LoadingLoop                 = 2,
	MT_MAX                         = 3
};



}

