#pragma once

// PlayerUnKnowns BattleGrounds Global-64bit (3.2.0) SDK BY @MirWani 

namespace SDK
{
//---------------------by MirWani---------------------------
//Enums
//---------------------by MirWani---------------------------

// Enum OodleNetworkHandlerComponent.EOodleNetworkEnableMode
enum class EOodleNetworkEnableMode : uint8_t
{
	EOodleNetworkEnableMode__AlwaysEnabled = 0,
	EOodleNetworkEnableMode__WhenCompressedPacketReceived = 1,
	EOodleNetworkEnableMode__EOodleNetworkEnableMode_MAX = 2
};



}

