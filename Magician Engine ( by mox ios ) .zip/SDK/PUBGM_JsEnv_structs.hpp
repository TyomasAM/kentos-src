#pragma once

// PlayerUnKnowns BattleGrounds Global-64bit (3.2.0) SDK BY @MirWani 

namespace SDK
{
//---------------------by MirWani---------------------------
//Script Structs
//---------------------by MirWani---------------------------

// ScriptStruct JsEnv.PropertyMetaRoot
// 0x0001
struct FPropertyMetaRoot
{
	unsigned char                                      UnknownData00[0x1];                                       // 0x0000(0x0001) MISSED OFFSET
};

// ScriptStruct JsEnv.ArrayBuffer
// 0x0018
struct FArrayBuffer
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0000(0x0018) MISSED OFFSET
};

// ScriptStruct JsEnv.JsObject
// 0x0060
struct FJsObject
{
	unsigned char                                      UnknownData00[0x60];                                      // 0x0000(0x0060) MISSED OFFSET
};

}

