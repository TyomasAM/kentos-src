#pragma once

// PlayerUnKnowns BattleGrounds Global-64bit (3.2.0) SDK BY @MirWani 

namespace SDK
{
//---------------------by MirWani---------------------------
//Enums
//---------------------by MirWani---------------------------

// Enum QDevKit.EQFirebaseRemoteConfigStatus
enum class EQFirebaseRemoteConfigStatus : uint8_t
{
	EQFirebaseRemoteConfigStatus__kUnfetched = 0,
	EQFirebaseRemoteConfigStatus__kFetchedSuccessfully = 1,
	EQFirebaseRemoteConfigStatus__kFetchedFailed = 2,
	EQFirebaseRemoteConfigStatus__EQFirebaseRemoteConfigStatus_MAX = 3
};



}

