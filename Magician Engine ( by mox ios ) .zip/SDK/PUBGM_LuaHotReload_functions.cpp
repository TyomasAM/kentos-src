// PlayerUnKnowns BattleGrounds Global-64bit (3.2.0) SDK BY @MirWani 

#include "../SDK.hpp"

namespace SDK
{
//---------------------by MirWani---------------------------
//Functions
//---------------------by MirWani---------------------------

// Function LuaHotReload.LuaHotReloadHelper.OnLuaFileHotUpdate
// (Final, Native, Public)
// Parameters:
// struct FString                 NotifyMessage                  (Parm, ZeroConstructor)

void ULuaHotReloadHelper::OnLuaFileHotUpdate(const struct FString& NotifyMessage)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function LuaHotReload.LuaHotReloadHelper.OnLuaFileHotUpdate");

	ULuaHotReloadHelper_OnLuaFileHotUpdate_Params params;
	params.NotifyMessage = NotifyMessage;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

