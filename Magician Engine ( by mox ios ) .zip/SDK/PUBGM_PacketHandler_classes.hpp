#pragma once

// PlayerUnKnowns BattleGrounds Global-64bit (3.2.0) SDK BY @MirWani 

namespace SDK
{
//---------------------by MirWani---------------------------
//Classes
//---------------------by MirWani---------------------------

// Class PacketHandler.HandlerComponentFactory
// 0x0000 (0x0028 - 0x0028)
class UHandlerComponentFactory : public UObject
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PacketHandler.HandlerComponentFactory");
		return pStaticClass;
	}

};


}

