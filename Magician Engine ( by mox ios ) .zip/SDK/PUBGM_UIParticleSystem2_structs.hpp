#pragma once

// PlayerUnKnowns BattleGrounds Global-64bit (3.2.0) SDK BY @MirWani 

namespace SDK
{
//---------------------by MirWani---------------------------
//Enums
//---------------------by MirWani---------------------------

// Enum UIParticleSystem2.UIMeshProjectionMethod
enum class EUIMeshProjectionMethod : uint8_t
{
	YOZOrtho                       = 0,
	XOYOrtho                       = 1,
	YOZPerspectiveFullScreen       = 2,
	YOZPerspectiveLocal            = 3,
	UIMeshProjectionMethod_MAX     = 4
};



}

