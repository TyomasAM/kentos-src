#pragma once

// PlayerUnKnowns BattleGrounds Global-64bit (3.2.0) SDK BY @MirWani 

#include "../SDK.hpp"

namespace SDK
{
//---------------------by MirWani---------------------------
//Parameters
//---------------------by MirWani---------------------------

// Function TableResInclude.EvoBaseMapUIMarkTableMap.TraversTable
struct UEvoBaseMapUIMarkTableMap_TraversTable_Params
{
	class UUAEDataTable*                               TableData;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       Key;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function TableResInclude.EvoBaseModTableTestTableMap.TraversTable
struct UEvoBaseModTableTestTableMap_TraversTable_Params
{
	class UUAEDataTable*                               TableData;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       Key;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

}

