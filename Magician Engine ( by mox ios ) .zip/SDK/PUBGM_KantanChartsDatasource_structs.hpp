#pragma once

// PlayerUnKnowns BattleGrounds Global-64bit (3.2.0) SDK BY @MirWani 

namespace SDK
{
//---------------------by MirWani---------------------------
//Script Structs
//---------------------by MirWani---------------------------

// ScriptStruct KantanChartsDatasource.KantanCartesianDatapoint
// 0x0008
struct FKantanCartesianDatapoint
{
	struct FVector2D                                   Coords;                                                   // 0x0000(0x0008) (Edit, BlueprintVisible, IsPlainOldData)
};

}

