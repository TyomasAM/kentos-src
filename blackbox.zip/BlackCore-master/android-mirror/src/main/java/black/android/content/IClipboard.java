package black.android.content;


import top.niunaijun.blackreflection.annotation.BClassName;

@BClassName("android.content.IClipboard")
public interface IClipboard {
}
