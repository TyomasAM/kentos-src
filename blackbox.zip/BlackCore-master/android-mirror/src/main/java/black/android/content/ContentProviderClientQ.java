package black.android.content;


import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BConstructor;

@BClassName("android.content.ContentProviderClient")
public interface ContentProviderClientQ {
    @BConstructor
    ContentProviderClientQ _new();
}
