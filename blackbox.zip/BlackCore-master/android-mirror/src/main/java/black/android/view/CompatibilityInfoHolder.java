package black.android.view;


import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BMethod;

@BClassName("android.view.CompatibilityInfoHolder")
public interface CompatibilityInfoHolder {
    @BMethod
    void set();
}
