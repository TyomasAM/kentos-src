package black.android.os;


import top.niunaijun.blackreflection.annotation.BClassName;

@BClassName("android.os.Build")
public interface Build {
}
