package black.com.android.internal.telephony;


import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BStaticField;

@BClassName("com.android.internal.telephony.PhoneConstants")
public interface PhoneConstantsMtk {
    @BStaticField
    int GEMINI_SIM_NUM();
}
