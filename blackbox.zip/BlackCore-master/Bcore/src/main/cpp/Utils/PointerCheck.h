//
// Created by Milk on 2021/5/17.
//

#ifndef BLACKBOX_POINTERCHECK_H
#define BLACKBOX_POINTERCHECK_H


class PointerCheck {
public:
    static bool check(void *addr);
};


#endif //BLACKBOX_POINTERCHECK_H
