package android.content.res;

import android.os.Parcel;
import android.os.Parcelable;

public class CompatibilityInfo implements Parcelable {
	@Override
	public int describeContents() {
		throw new UnsupportedOperationException("Stub!");
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		throw new UnsupportedOperationException("Stub!");
	}

	public static final Creator<CompatibilityInfo> CREATOR = null;
}
